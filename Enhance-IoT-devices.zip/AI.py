from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
import pandas as pd
import joblib
import os

# Load data
df = pd.read_csv('data.csv')

# Clean and transform
df = df.dropna(subset=['Time_Access', 'Accessed_From_Local', 'Login_Failed_Count', 'IP_Address', 'y'])

# Parse timestamp and extract hour
df['Time_Access'] = pd.to_datetime(df['Time_Access'], errors='coerce')
df = df.dropna(subset=['Time_Access'])
df['Hour'] = df['Time_Access'].dt.hour

# Encode 'Accessed_From_Local'
df['Is_Local'] = df['Accessed_From_Local'].map({'Yes': 1, 'No': 0})

# Define feature matrix and target
X = df[['Hour', 'Is_Local', 'Login_Failed_Count']]
y = df['y']

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)

# Evaluate
y_pred = model.predict(X_test)
print(classification_report(y_test, y_pred))

# Save model
desktop_path = os.path.expanduser("~/Desktop/iot_anomaly_model.pkl")
os.makedirs(os.path.dirname(desktop_path), exist_ok=True)
joblib.dump(model, desktop_path)
print(f"✅ Model saved to: {desktop_path}")
