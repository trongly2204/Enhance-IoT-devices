function check_default() {
    const default_password = document.getElementById("default_password").value;
    const messageEl = document.getElementById("default-message");

    fetch('/register_condition', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ default_password })
    })
    .then(response => response.json().then(data => ({ status: response.status, body: data })))
    .then(({ status, body }) => {
        if (status !== 200) {
            messageEl.style.color = "red";
            switch (body.message) {
                case "SD card is not inserted":
                    messageEl.textContent = "Please insert the SD card.";
                    break;
                case "Default password does not match":
                    messageEl.textContent = "The default password is incorrect.";
                    break;
                default:
                    messageEl.textContent = body.message || "Verification failed.";
            }
        } else {
            messageEl.style.color = "green";
            messageEl.textContent = body.message || "Verified successfully!";
            setTimeout(() => {
                window.location.href = "/register_page";
            }, 1000);
        }
    })
    .catch(error => {
        console.error('Default check error:', error);
        messageEl.style.color = "red";
        messageEl.textContent = "Something went wrong during default check.";
    });
}




function check_exist_account() {
    const exist_username = document.getElementById("exist_username").value;
    const exist_password = document.getElementById("exist_password").value;
    const messageEl = document.getElementById("exist-account-message");

    fetch('/register_condition', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ exist_username, exist_password })
    })
    .then(response => response.json().then(data => ({ status: response.status, body: data })))
    .then(({ status, body }) => {
        if (status !== 200) {
            messageEl.style.color = "red";
            switch (body.message) {
                case "SD card is not inserted":
                    messageEl.textContent = "Please insert the SD card.";
                    break;
                case "Invalid username":
                    messageEl.textContent = "This username does not exist.";
                    break;
                case "Password does not match":
                    messageEl.textContent = "Incorrect password.";
                    break;
                default:
                    messageEl.textContent = body.message || "Verification failed.";
            }
        } else {
            messageEl.style.color = "green";
            messageEl.textContent = body.message || "Verified successfully!";
            setTimeout(() => {
                window.location.href = "/register_page";
            }, 1000);
        }
    })
    .catch(error => {
        console.error('Exist account check error:', error);
        messageEl.style.color = "red";
        messageEl.textContent = "Something went wrong during account check.";
    });
}



function set_up_stage(){
    fetch('/setup_stage')
    .then(response => response.json())
    .then(data => {
        if (data.stage === "no_account") {
            document.getElementById("signup_with_no_accountexist").style.display = "block";
        } else {
            document.getElementById("signup_with_accountexist").style.display = "block";
        }
    });
}
function view_logs(){
    const messageEl = document.getElementById("log-output");

    fetch('/view_logs')
    .then(response => response.json())
    .then(data => {
        if (data.status === "error") {
            messageEl.style.color = "red";
            messageEl.textContent = "Log file not found.";
        } else {
            messageEl.style.color = "green";
            // Join lines into a readable format if it's an array
            if (Array.isArray(data.message)) {
                messageEl.textContent = data.message.join("\n");
            } else {
                messageEl.textContent = data.message;
            }
        }
    })
    .catch(error => {
        console.error("Error reading log:", error);
        messageEl.style.color = "red";
        messageEl.textContent = "Something went wrong while reading the log.";
    });
}

function login() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    const messageEl = document.getElementById("login-message");

    fetch('/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
    })
    .then(response => response.json().then(data => ({ status: response.status, body: data })))
    .then(({ status, body }) => {
        if (status !== 200) {
            messageEl.style.color = "red";
            switch (body.message) {
                case "Missing fields":
                    messageEl.textContent = "Please fill in both fields.";
                    break;
                case "User not found":
                    messageEl.textContent = "User not found.";
                    break;
                case "Password incorrect":
                    messageEl.textContent = "Incorrect password.";
                    break;
                case "Account locked":
                    messageEl.textContent = "Account is locked. Contact support.";
                    break;
                default:
                    messageEl.textContent = body.message || "Login failed.";
            }
        } else {
            messageEl.style.color = "green";
            messageEl.textContent = body.message || "Login successful!";
            setTimeout(() => {
                window.location.href = "/home_page";
            }, 1000);
        }
    })
    .catch(error => {
        console.error('Login error:', error);
        messageEl.style.color = "red";
        messageEl.textContent = "Something went wrong while logging in.";
    });
}

function register() {
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    const email = document.getElementById("email").value;
    const messageEl = document.getElementById("register-message");

    fetch('/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password, email })
    })
    .then(response => response.json().then(data => ({ status: response.status, body: data })))
    .then(({ status, body }) => {
        if (status !== 200) {
            messageEl.style.color = "red";
            switch (body.message) {
                case "SD card is not inserted":
                    messageEl.textContent = "Insert the SD card before registering.";
                    break;
                case "Missing fields":
                    messageEl.textContent = "Please fill in all fields.";
                    break;
                case "Username already exists":
                    messageEl.textContent = "Username is already taken.";
                    break;
                case "Email already exists":
                    messageEl.textContent = "This email is already used.";
                    break;
                default:
                    messageEl.textContent = body.message || "Registration failed.";
            }
        } else {
            messageEl.style.color = "green";
            messageEl.textContent = body.message || "Account created successfully!";
        }
    })
    .catch(error => {
        console.error('Register error:', error);
        messageEl.style.color = "red";
        messageEl.textContent = "Something went wrong during registration.";
    });
}
