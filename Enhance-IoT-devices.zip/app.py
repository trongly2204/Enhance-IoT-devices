from flask import Flask, jsonify, request, render_template
import os
import security_functions as sec

app = Flask(__name__, template_folder = "templates")

@app.route('/')
def index():
    return render_template("index.html") 
@app.route('/signup_condition')
def signup_condition():
    return render_template("signup_condition.html")
@app.route('/register_page')
def register_page():
    return render_template("register_page.html")
@app.route('/home_page')
def home_page():
    return render_template("homepage.html")
@app.route('/setup_stage', methods=['GET'])
def setup_stage():
    if not sec.check_defaultpass_exist():
        return jsonify({"stage": "no_account"})
    else:
        return jsonify({"stage": "account_exists"})

@app.route('/register_condition', methods=['POST'])
def register_condition():
    data = request.get_json()

    # Step 1: Check SD card
    if not sec.check_SD_card():
        return jsonify({"status": "error", "message": "SD card is not inserted"}), 409

    # Step 2: If default password is required (first time setup)
    if not sec.check_defaultpass_exist():
        default_password = data.get("default_password")
        if not sec.check_default_pass(default_password):
            return jsonify({"status": "error", "message": "Default password does not match"}), 409

    # Step 3: If default password already set, require authentication
    if sec.check_defaultpass_exist():

        exist_username = data.get("exist_username")
        exist_password = data.get("exist_password")

        username_map, _ = sec.load_userinfo_todict()

        if exist_username not in username_map:
            return jsonify({"status": "error", "message": "Invalid username"}), 401

        if sec.hash_text(exist_password) != username_map[exist_username]['password']:
            return jsonify({"status": "error", "message": "Password does not match"}), 401
    return jsonify({"status": "success", "message": "Verify successfully!"}), 200
@app.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    if not sec.check_SD_card():
        return jsonify({"status": "error", "message": "SD card is not inserted"}), 409
    username = data.get("username")
    password = data.get("password")
    email = data.get("email")

    if not all([username, password, email]):
        return jsonify({"status": "error", "message": "Missing fields"}), 400

    if sec.check_user_exist(username):
        return jsonify({"status": "error", "message": "Username already exists"}), 409

    if sec.check_email_exist(email):
        return jsonify({"status": "error", "message": "Email already exists"}), 409

    # Step 5: Create account
    message = sec.set_up_account(username, password, email)

    return jsonify({"status": "success", "message": message}), 200

# User login
@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")

    if not all([username, password]):
        return jsonify({"status": "error", "message": "Missing fields"}), 400

    message = sec.login(username, password)
    if "Locked" in message or "Anomalous" in message:
        sec.send_alert(username)
        return jsonify({"status": "error", "message": message}), 403
    if "Successful" in message:
        return jsonify({"status": "success", "message": message}), 200
    return jsonify({"status": "error", "message": message}), 401


# View log file
@app.route('/view_logs', methods=['GET'])
def view_logs():
    log_lines = sec.read_log_file()
    if log_lines is None:
        return {"status": "error", "message": "Log file not found."}, 404
    return {"status": "success", "message": log_lines}, 200
if __name__ == '__main__':
    app.run(debug=True)
