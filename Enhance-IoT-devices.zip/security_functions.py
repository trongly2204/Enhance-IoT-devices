import os
import requests
import logging
import hashlib
import time
from datetime import datetime
from ipaddress import ip_network, ip_address as ip_obj
import smtplib
from email.message import EmailMessage
import joblib
import socket
import struct

# Constants
SD_path = "/Volumes/SD Card"
user_info_path = os.path.join(SD_path, "user.txt")
logfile_path = os.path.join(SD_path, "logfile.txt")
default_password = "admin123"
failed_attempts_remaining = {}
MAX_ATTEMPTS = 5
base_dir = os.path.dirname(os.path.abspath(__file__))
model_path = os.path.join(base_dir, "iot_anomaly_model.pkl")
anomaly_model = joblib.load(model_path)

# Logging setup
def append_logging():
    logging.basicConfig(
        filename=logfile_path,
        filemode="a",
        format="%(asctime)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        level=logging.INFO
    )

def log_access(username, is_local, failed_limit, ip_address):
    append_logging()
    accessed_from_local = "Yes" if is_local else "No"
    log_message = (
        f"Username: {username}, "
        f"Accessed_From_Local: {accessed_from_local}, "
        f"Login_Failed: {failed_limit}, "
        f"IP_Address: {ip_address}"
    )
    logging.info(log_message)

# Convert IP to numeric
def ip_to_int(ip):
    try:
        return struct.unpack("!I", socket.inet_aton(ip))[0]
    except:
        return 0

def extract_features(is_local, failed_count, ip):
    hour = datetime.now().hour
    is_local_binary = 1 if is_local else 0
    ip_numeric = ip_to_int(ip)
    return [hour, is_local_binary, failed_count]

# Get public IP
def ip_address():
    try:
        ip = requests.get("https://api.ipify.org").text
        return ip
    except:
        return "Unavailable"

# IP classification
def check_local_ipaddress(ip):
    try:
        ip_obj_instance = ip_obj(ip)
        if (ip_obj_instance in ip_network("192.168.0.0/16") or
                ip_obj_instance in ip_network("10.0.0.0/8") or
                ip_obj_instance in ip_network("172.16.0.0/12")):
            return True
    except ValueError:
        return False

# Hashing
def hash_text(text):
    return hashlib.sha256(text.encode()).hexdigest()

# Log file reader
def read_log_file():
    try:
        with open(logfile_path, 'r') as f:
            return f.readlines()
    except FileNotFoundError:
        return None

# SD card check
def check_SD_card():
    return os.path.exists(SD_path)

def check_default_pass(default_pass):
    return default_pass == default_password

def check_defaultpass_exist():
    return os.path.exists(user_info_path)

def load_userinfo_todict():
    users_map = {}
    email_map = {}
    if not os.path.exists(SD_path):
        os.makedirs(SD_path)

    # Ensure user_info_path file exists
    if not os.path.exists(user_info_path):
        with open(user_info_path, 'w') as u:
            pass  # create an empty file
    with open(user_info_path, 'r') as u:
        for line in u:
            parts = line.strip().split(',')
            if len(parts) == 3:
                username, password, email = parts
                users_map[username] = {
                    'password': password,
                    'email': email
                }
                email_map[email] = username
    return users_map, email_map

def check_email_exist(target_email):
    _, email_map = load_userinfo_todict()
    return target_email in email_map

def check_user_exist(target_user):
    users_map, _ = load_userinfo_todict()
    return target_user in users_map

def set_up_account(username, password, email):
    with open(user_info_path, 'a') as u:
        u.write(f"{username},{hash_text(password)},{email}\n")
    return "User registered successfully."

def change_password(username, old_password, new_password):
    users_map, _ = load_userinfo_todict()
    stored_password = users_map[username].get('password')

    if hash_text(old_password) != stored_password:
        return "Incorrect old password."

    users_map[username]['password'] = hash_text(new_password)

    with open(user_info_path, 'w') as u:
        for user, info in users_map.items():
            line = f"{user},{info['password']},{info['email']}\n"
            u.write(line)
    return "Password changed successfully."

def login(username, password):
    users_map, _ = load_userinfo_todict()
    ip = ip_address()
    is_local = check_local_ipaddress(ip)

    if username not in failed_attempts_remaining:
        failed_attempts_remaining[username] = MAX_ATTEMPTS
        log_access(username, is_local, MAX_ATTEMPTS, ip)

    if failed_attempts_remaining[username] == 0:
        log_access(username, is_local, 0, ip)
        return "Locked"

    features = extract_features(is_local, failed_attempts_remaining[username], ip)
    is_anomaly = anomaly_model.predict([features])[0] == -1

    if is_anomaly:
        log_access(username, is_local, failed_attempts_remaining[username], ip)
        return "Anomalous login behavior detected. Access denied."

    if username in users_map and hash_text(password) == users_map[username]['password']:
        log_access(username, is_local, failed_attempts_remaining[username], ip)
        failed_attempts_remaining[username] = MAX_ATTEMPTS
        return "Successful!"
    else:
        failed_attempts_remaining[username] -= 1
        log_access(username, is_local, failed_attempts_remaining[username], ip)
        return f"Incorrect password. Attempts left: {failed_attempts_remaining[username]}"

# Send alert via email
def send_alert(username, subject="Alert", body="An alert has been triggered!"):
    users_map, _ = load_userinfo_todict()
    message = ""

    user_info = users_map.get(username)
    if not user_info:
        return "❌ Username not found."

    to_email = user_info['email']
    if not to_email:
        return "❌ No email found for this user."

    smtp_server = "smtp.gmail.com"
    smtp_port = 587
    sender_email = "lytronghieu1997faker@gmail.com"
    sender_password = "crzkdbtfmasqwita"  # App password

    msg = EmailMessage()
    msg.set_content(body)
    msg["Subject"] = subject
    msg["From"] = sender_email
    msg["To"] = to_email

    try:
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()
            server.login(sender_email, sender_password)
            server.send_message(msg)
        message = f"Email sent to {to_email}"
    except Exception as e:
        message = f"Failed to send email: {e}"

    return message
